/**
 * 
 */
/**
 * @author yutanagasaka
 *
 */
module guiDemo {
}